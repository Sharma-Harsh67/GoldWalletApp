package com.wallet.app.serviceimpl;

import com.wallet.app.model.Users;
import com.wallet.app.repository.UsersRepositoryJoshika;
import com.wallet.app.service.UsersServiceJoshika;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsersServiceImplJoshika implements UsersServiceJoshika {


public UsersServiceImplJoshika(UsersRepositoryJoshika userRepository) {
		super();
		this.userRepository = userRepository;
	}

private UsersRepositoryJoshika userRepository;

@Override
public List<Users> getAllUsers() {
return userRepository.findAll();
}




}

